# Chordle
Wordle but for music chords

Inspired from: https://www.chordle.synthase.cc/
